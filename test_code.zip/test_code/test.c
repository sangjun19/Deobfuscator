#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_STUDENTS 100
#define NAME_LEN 50

// Student structure
typedef struct {
    int id;
    char name[NAME_LEN];
    int age;
    double gpa;
} Student;

// Student list
Student students[MAX_STUDENTS];
int studentCount = 0;

// Add a new student
void addStudent(int id, const char *name, int age, double gpa) {
    if (studentCount >= MAX_STUDENTS) {
        printf("Cannot add more students. List is full.\n");
        return;
    }
    students[studentCount].id = id;
    strncpy(students[studentCount].name, name, NAME_LEN - 1);
    students[studentCount].name[NAME_LEN - 1] = '\0'; // safe copy
    students[studentCount].age = age;
    students[studentCount].gpa = gpa;
    studentCount++;
}

// Print all students
void printAllStudents() {
    printf("\n=== Student List ===\n");
    for (int i = 0; i < studentCount; i++) {
        printf("ID: %d, Name: %s, Age: %d, GPA: %.2f\n",
               students[i].id, students[i].name,
               students[i].age, students[i].gpa);
    }
    printf("====================\n\n");
}

// Search for a student by name
void searchStudentByName(const char *name) {
    printf("\nSearch results for '%s':\n", name);
    int found = 0;
    for (int i = 0; i < studentCount; i++) {
        if (strcmp(students[i].name, name) == 0) {
            printf("ID: %d, Name: %s, Age: %d, GPA: %.2f\n",
                   students[i].id, students[i].name,
                   students[i].age, students[i].gpa);
            found = 1;
        }
    }
    if (!found) {
        printf("No student found with that name.\n");
    }
    printf("\n");
}

// Calculate average GPA
double calculateAverageGPA() {
    if (studentCount == 0) return 0.0;
    double sum = 0;
    for (int i = 0; i < studentCount; i++) {
        sum += students[i].gpa;
    }
    return sum / studentCount;
}

int main() {
    int choice;
    while (1) {
        printf("=== Student Management System ===\n");
        printf("1. Add Student\n");
        printf("2. Print All Students\n");
        printf("3. Search Student by Name\n");
        printf("4. Show Average GPA\n");
        printf("5. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        if (choice == 1) {
            int id, age;
            char name[NAME_LEN];
            double gpa;
            printf("Enter ID: ");
            scanf("%d", &id);
            printf("Enter Name: ");
            scanf("%s", name);
            printf("Enter Age: ");
            scanf("%d", &age);
            printf("Enter GPA: ");
            scanf("%lf", &gpa);
            addStudent(id, name, age, gpa);
        } else if (choice == 2) {
            printAllStudents();
        } else if (choice == 3) {
            char name[NAME_LEN];
            printf("Enter name to search: ");
            scanf("%s", name);
            searchStudentByName(name);
        } else if (choice == 4) {
            printf("Average GPA of all students: %.2f\n\n", calculateAverageGPA());
        } else if (choice == 5) {
            printf("Exiting program. Goodbye!\n");
            break;
        } else {
            printf("Invalid choice. Try again.\n\n");
        }
    }

    return 0;
}
