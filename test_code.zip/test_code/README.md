## 파일 및 폴더 설명

- **test.c** : 원본 C 소스 코드 파일
- **test_vir.c** : test.c에 Tigress Virtualize 적용
- **test_vir.bc** : test_vir.c를 컴파일한 LLVM IR 바이트코드
- **test_vir.ll** : test_vir.bc 확인용 LLVM IR
- **test_vir_hub.bc** : test_vir.bc에 FindHubBlockPass.so(Dispatch dummy function) 적용
- **test_vir_hub.ll** : test_vir_hub.bc 확인용
- **splitted/test_vir.c** : test_vir_hub.bc를 입력으로 분할 후 chunk 집합 폴더
- **merged1/test_vir.c** : splitted/test_vir.c의 chunk들을 일정 기준으로 재합병한 결과